<?php
$servername = "MangoMC"; // Tên máy chủ
$logo = "'../images/logo.png'"; // Logo xuất hiện
$title= "MangoMC - Máy chủ minecraft việt nam"; // Tiêu đề
$home = "Trang chủ"; // Mấy cái nút
$giftcode = "Giftcode"; // Mấy cái nút
$event = "Sự kiện"; // Mấy cái nút
$napthe = "Nạp thẻ"; // Mấy cái nút
$news = "Thông báo"; // Mấy cái nút
// Liên kết (đường link) cho mấy cái Trang Chủ, Giftcode, Sự kiện,... bên trên
$homelink = "../"; // Để mặc định nha
$giftcodelink = ""; // Nếu có giftcode thì ghi đường dẫn nha :D
$eventlink = ""; // Nếu có event thì ghi đường dẫn nha :D
$napthelink = ""; // Tui chưa update nạp thẻ đâu :D
$newslink = ""; // Nếu có phần Thông báo thì ghi đường dẫn vô nghen :)
// Code by Đoàn Bảo. Configuration for mấy thằng ngu không biết edit code :).
// UPDATE !
// ! NOTE : DO CÓ MẤY THẰNG NGU NHƯ PHO1 ĐÉO BIẾT EDIT CODE NÊN TÔI PHẢI THÊM VÀI CÁI NÀY :(, DÙ NÓ LÀM XẤU CODE NHƯNG DỄ CHO MẤY THẰNG NGU CODE
?>
<?php
// Phần index.php (Trang chủ)
$indexnote = "Server mới khai trương ưu đãi 100% khi nạp thẻ được tặng thêm 100 points !"; // Hộp thông báo khai trương :D
$naptherc = "Nhấn để nạp ngay"; // :)
$btnnaprc = "Nạp ngay"; // Button nạp ngay
$btnnaplink = ""; // Link nạp thẻ khi nhấn vào button $btnnaprc
?>